//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
package Animal;

public class Main {
    static void main(String[] args){
        Dog Bolt = new Dog("Bolt", 2, "Husky");
        Cat Tom = new Cat("Tom", 3);

        Tom.isIndoor(true);
        System.out.println(Tom);

        System.out.println(Bolt);
        Bolt.train();
        Bolt.sit();
        System.out.println(Animal.numberOfAnimal);
    }
}
